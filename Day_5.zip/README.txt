This Code Refactoring assignment was completed by Umaima Siddiqui(2303.KHI.DEG.033)
and Muhammad Talha(2303.KHI.DEG.024) in pair programming. 

What we did:

*) removed the import of pandas becacause we were not using pandas in the code.
*) created separate functions for separate task so they gets simplier to compose,
test, and reason about. 

