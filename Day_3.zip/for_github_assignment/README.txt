This Assignment is done by Muhammad Talha(2303.khi.deg.024) and Maaz Javaid Siddique((2303.khi.deg.004) in Pair Programming.
The instructions were very clear, the screenshot's names represents each step.
